package lab07;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class StringPermutationsTest {
    private StringPermutations stringPermutations;

    @Before
    public void setUp() {
        stringPermutations = new StringPermutations();
    }

    @Test
    public void shouldReturnEmptyForEmptyString() {
        String input = "";
        String[] expected = { "" };
        verifyPermutations(input, expected);
    }

    @Test
    public void shouldReturnSingleCharacterForSingleCharString() {
        String input = "a";
        String[] expected = { "a" };
        verifyPermutations(input, expected);
    }

    @Test
    public void shouldReturnTwoPermutationsForTwoCharacterString() {
        String input = "ab";
        String[] expected = { "ab", "ba" };
        verifyPermutations(input, expected);
    }

    @Test
    public void shouldReturnAllPermutationsForThreeCharacterString() {
        String input = "abc";
        String[] expected = { "abc", "acb", "bac", "bca", "cab", "cba" };
        verifyPermutations(input, expected);
    }

    @Test
    public void shouldReturnAllPermutationsForFourCharacterString() {
        String input = "abcd";
        String[] expected = { "abcd", "abdc", "acbd", "acdb", "adbc", "adcb",
                              "bacd", "badc", "bcad", "bcda", "bdac", "bdca",
                              "cabd", "cadb", "cbad", "cbda", "cdab", "cdba",
                              "dabc", "dacb", "dbac", "dbca", "dcab", "dcba" };
        verifyPermutations(input, expected);
    }

    private void verifyPermutations(String input, String[] expected) {
        String[] actual = stringPermutations.generatePermutations(input).toArray(new String[0]);
        
        // Verify that all expected permutations match actual permutations
        assertArrayEquals("Permutations do not match for input: " + input, expected, actual);
    }
}
